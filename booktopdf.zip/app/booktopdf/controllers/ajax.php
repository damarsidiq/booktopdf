<?php
Class Ajax extends Controller{
    function __construct(){
        parent::__construct();
    }
    
    public function rotateimage($data){
        $data = json_decode($data['rotated']);
        foreach($data as $k=>$v){
            $ext = explode('.',$v->src);
            $ext = strtolower($ext[count($ext)-1]);
            
            switch($ext){
                case 'jpg':
                case 'jpeg':
                    $rimg = imagecreatefromjpeg($v->src);
                break;
                case 'png':
                    $rimg = imagecreatefrompng($v->src);
            }
            
            $rdimage = imagerotate($rimg,(360-$v->rotation),0);
            
            $srcdest = App::getConfig('uploads');
            $vsrc = explode('/',$v->src);
            $vsrc = $vsrc[count($vsrc)-1];
            $srcdest .= $vsrc;
            
            switch($ext){
                case 'jpg':
                case 'jpeg':
                    $result = imagejpeg($rdimage,$srcdest);
                break;
                case 'png':
                    $result = imagepng($rdimage,$srcdest);
            }
            
            if(!$result){
                echo '0';
                return 'plain';
            }
            
            imagedestroy($rimg);
            imagedestroy($rdimage);
        }
        echo '1';
        return 'plain';
    }
    public function scanfolder($data){
        $filesarr = array();
        $filehandle = opendir(App::getConfig('uploads'));
        while(false !== ($files = readdir($filehandle))){
            if($files != '.' && $files != '..' && $files != 'thumbs'){
                $filesarr[] = App::getConfig('uploads').$files;
            }
        }
        closedir($filehandle);
        
        if(count($filesarr)>0){
            sort($filesarr);
        }
        $this->setPagevar('response',$filesarr);
        
        return 'ajax';
    }
    
    public function makepdf(){
        $filesarr = array();
        $filehandle = opendir(App::getConfig('uploads'));
        while(false !== ($files = readdir($filehandle))){
            if($files != '.' && $files != '..' && $files != 'thumbs'){
                $filesarr[] = App::getConfig('uploads').$files;
            }
        }
        closedir($filehandle);
        
        if(count($filesarr)>0){
            sort($filesarr);
            foreach($filesarr as $k=>$v){
                $this->model('pdfbook')->bookimages[] = $v;
            }
            $this->model('pdfbook')->outputdompdf('portrait');
        }
    }
}
?>