const electron = require('electron')
const app = electron.app
const BrowserWindow = electron.BrowserWindow

let win

function draw() {
    win = new BrowserWindow({ icon:'/media/damarsidiq/pic/icons/booktopdf.png', width: 1000, height: 600, resizable: true,y:0,x:200,frame:false ,webPreferences: {
      plugins:true,webSecurity:false,allowRunningInsecureContent:true,experimentalFeatures:true,experimentalCanvasFeatures:true,webviewTag:true,nativeWindowOpen:true
    } });
    win.webContents.session.clearCache(function(){});
//win.webContents.openDevTools();
    win.setTitle('BookToPDF');
    win.setMenuBarVisibility(false);
    //win.setMenu(null);
    win.isMaximizable(true);
    win.isResizable(true);
    win.setAlwaysOnTop(false, "floating");
    win.loadURL('http://pxpedia/pxpedia/?app=booktopdf&d[electronapp]=1');
    win.show();
}
app.on('ready', draw)
