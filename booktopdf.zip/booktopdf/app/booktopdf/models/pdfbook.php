<?php 
Class Pdfbook extends Model{
    var $pdfheader;
    var $pdfcontent;
    var $bookimages;
    
	function __construct(){
		parent::__construct();
		
        $this->pdfheader    = '<style type="text/css"><!-- html{font-family:Arial;} p{display: block;margin-bottom: 1em;margin-top: 1em;}  --></style>';
        $this->pdfcontent = '';
        $this->bookimages = array();
	}
	public function makecontent($orientation){
         $a4 = $orientation == 'landscape' ? array('72'=>array(595,842),'96'=>array(794,1123),'150'=>array(1240,1754),'300'=>array(2480,3508)) : array('72'=>array(842,595),'96'=>array(1123,794),'150'=>array(1754,1240),'300'=>array(3508,2480));
         
         $value = '<div style="text-align:center;margin-top:'. ((($a4['96'][0]-90)/2)-200) .'px;font-size:20px;height:30px;line-height:30px;width:100%;page-break-before:avoid;page-break-after:avoid;"><b>Generated with BookToPDF</b> (www.github.com/damarsidiq)</div>';
         foreach ($this->bookimages as $l=>$img) {
             //echo $l.$img.'<br/>';
            list($width,$height) = getimagesize($img);
            

            $marginleft= $width<($a4['96'][1]-90) ? ((($a4['96'][1]-90)-$width)/2) : 0;
            $width = $marginleft == 0 ? ($a4['96'][1]-90) : $width;
            $height= min($height,($a4['96'][0]-90));
            
                 
            $value .= '<div style="height:'.$height.'px;margin:auto;margin-left:'.$marginleft.'px;width:'.$width.'px;page-break-before:avoid;page-break-after:avoid;clear:both;text-align:center;height:'.$height.'px;"><img src="'.$img.'" width='.$width.' height='.$height.'></div>';
             
         }
         return $value;
    }
	 public function outputdompdf($orientation){
        require_once Pxpedia::getConfig('resources').'dompdf/lib/html5lib/Parser.php';
        require_once Pxpedia::getConfig('resources').'dompdf/lib/php-font-lib/src/FontLib/Autoloader.php';
        require_once Pxpedia::getConfig('resources').'dompdf/lib/php-svg-lib/src/autoload.php';
        require_once Pxpedia::getConfig('resources').'dompdf/src/Autoloader.php';


        require_once Pxpedia::getConfig('resources').'dompdf/src/CanvasFactory.php';
        require_once Pxpedia::getConfig('resources').'dompdf/src/Options.php';
        require_once Pxpedia::getConfig('resources').'dompdf/src/Dompdf.php';
        Dompdf\Autoloader::register();

        $dompdf = new Dompdf\Dompdf();
        
        $this->pdfcontent = $this->makecontent($orientation);
        
        $dompdf->loadHtml($this->pdfheader.$this->pdfcontent);
        $dompdf->setPaper('A4', $orientation);
        $dompdf->render();

        //echo $this->pdfheader.$this->pdfcontent;
        $this->pdfcontent = '';
        //exit();

        $dompdf->stream();
    }
}
?>
