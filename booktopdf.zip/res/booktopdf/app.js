$(document).ready(
    function () {
        $('body').delegate('#scanfolderbtn','click',function(event){
            event.stopPropagation();
            
            pageloading();
            
            $.ajax({
                url:'./',
                type:'POST',
                data:{app:appname,p:'ajax',a:'scanfolder',d:{}}
            }).done(function(msg){
                msg = JSON.parse(msg);
                photobook.loaded = msg.length;
                
                $('#content').html('<ul id="photobook"></ul>');
                for(var i=0;i<msg.length;i++){
                    photobook.loadphoto(msg[i],i);
                }
                pageunload();
            });
        });
        
        $('body').delegate('#makepdf','click',function(event){
            event.stopPropagation();
            
            $(this).addClass('loading');
            photobook.downloadpdf();
        });
        
        $('body').delegate('.rotate','click',function(event){
            event.stopPropagation();
            
            photobook.rotateimg($(this).parent().attr('id').split('_')[1]);
        });
        
        $('body').delegate('#resetbook','click',function(event){
            event.stopPropagation();
            
            photobook.resetbook();
            $('#content').html('<div id="btncont"><div id="scanfolderbtn">Start</div></div>').addClass('initial');
        });
    }
);

var photobook = {
    resetbook:function(){
        this.bookphotos = [];
    },
    bookphotos:[],
    loaded:0,
    downloadpdf:function(){
        var rotated = [];
        var rotatedidx = 0;
        for(var i=0;i<this.bookphotos.length;i++){
            if(this.bookphotos[i].rotation > 0){
                rotated[rotatedidx] = {src:this.bookphotos[i].image.src,rotation:this.bookphotos[i].rotation};
                
                rotatedidx++;
            }
        }
        
        if(rotatedidx>0){
            $.ajax({
                url:'./',
                type:'POST',
                data:{app:appname,p:'ajax',a:'rotateimage',d:{rotated:JSON.stringify(rotated)}},
            }).done(function(msg){
                if(msg == '0'){
                    return;
                }
                photobook.getpdf();
            });
        }
        else{
            photobook.getpdf();
        }
    },
    getpdf:function(){
        window.open('./?app='+appname+'&p=ajax&a=makepdf');
        $('#makepdf').removeClass('loading');
    },
    rotateimg:function(id){
        id=parseInt(id);
        this.bookphotos[id].rotation += 90;
        if(this.bookphotos[id].rotation == 360){
            this.bookphotos[id].rotation = 0;
            $('#pbimg_'+id).css('transform','');
        }
        else{
            $('#pbimg_'+id).css('transform','rotate('+this.bookphotos[id].rotation+'deg)');
        }
    },
    loadphoto:function(url,id){
        var idx = this.bookphotos.length;
        this.bookphotos[idx] = [];
        this.bookphotos[idx].image = new Image();
        this.bookphotos[idx].image.src = url;
        this.bookphotos[idx].rotation = 0;
        
        $('#photobook').append('<li id="photoid_'+id+'" class="pbook loading"><div class="rotate">&olarr;</div></li>');
        
        this.bookphotos[idx].image.onload = function(){
            $('#photoid_'+id).append('<img src="'+this.src+'" class="pbimg" id="pbimg_'+id+'">').removeClass('loading');
            photobook.loaded--;
        }
    }
};

function pageloading(){
    $('#content').addClass('loading');
}
function pageunload(){
    $('#content').removeClass('loading initial');
    $('#content').append('<div id="makepdf"></div><div id="resetbook"></div>');
}